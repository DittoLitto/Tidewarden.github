# Tidewarden — Android project

Native Android wrapper (WebView) around the Tidewarden HTML5 game. Fully offline, no INTERNET permission.
Package: `com.chandlerfullen.tidewarden` · minSdk 24 (Android 7+) · targetSdk 34.

## Get an installable APK (pick one)

### A) GitHub — no installs needed (easiest)
1. Create a new GitHub repo and upload the contents of this folder (keep the `.github` folder).
2. Open the **Actions** tab → **Build Android APK** → **Run workflow** (it also runs on every push).
3. When it finishes (~3–5 min), open the run and download the **Tidewarden-debug-apk** artifact, unzip, and
   transfer `app-debug.apk` to your phone. Allow "Install unknown apps" when prompted.

### B) Android Studio
1. File → Open → select this folder. Let Gradle sync (it will fetch the SDK pieces it needs).
2. Plug in a phone (USB debugging on) and press ▶ Run — or Build → Build APK(s).
   APK lands in `app/build/outputs/apk/debug/`.

### C) Command line (Android SDK + JDK 17 installed, Gradle 8.7+)
```
gradle assembleDebug      # → app/build/outputs/apk/debug/app-debug.apk
```

## Quick test without building
Open `Tidewarden-test.html` (next to this folder) in Chrome on your phone. Same game, same saves logic.

## Where the game lives
`app/src/main/assets/index.html` — the entire game in one file. Edit it and rebuild.

## Publishing to Google Play later
Debug APKs are for testing. For the Play Store: create an upload keystore, add a `signingConfigs.release`
block in `app/build.gradle`, and run `gradle bundleRelease` to get an `.aab`.
